# Capstone Report — Content Refresh Opportunity Model

- **Author:** Mustafa Arfat
- **Lane:** Content refresh prioritization
- **Repo:** https://github.com/cust40078-sudo/flyrank-ml-internship
- **Date:** 2026-08-29

## 0. Abstract

FlyRank content teams need a practical way to decide which existing pages deserve refresh review when attention is limited. Using 30,000 rows from the bundled anonymized content-refresh dataset, I framed the task as predicting whether an existing content item is showing a declining performance signal and then ranking items for human review. I compared a transparent rules baseline with logistic regression, a decision tree, and a random forest using a client-holdout validation split and features available from content, search-demand, traffic, and engagement signals while excluding label-derived trend fields from the model features. The random forest was the strongest measured model on precision@50 (0.740) and ROC AUC (0.750), versus 0.240 precision@50 and 0.627 ROC AUC for the baseline rules. The resulting queue is a decision-support tool for editors: it helps focus review on higher-priority refresh opportunities, but it does not automatically decide what to publish or establish a causal effect on rankings.

## 1. Problem framing

The FlyRank content problem is prioritization: an editorial/SEO team may have many existing pages that could merit review, but limited time. The unit of analysis is an existing content item/page. The output is a decline-risk score plus a ranked queue and reason/action codes. A human editor uses that output to decide whether to refresh, inspect CTR or engagement, expand, or monitor a page. A wrong call costs review time or risks missing a useful refresh candidate.

## 2. Data safety

The analysis uses the bundled anonymized `content_refresh_anonymized.csv` release with 30,000 scored rows. Client/content IDs are used for grouping and traceability only, never as model features. The label is `is_declining_label`, defined as `trend_direction == "down"`. Label-derived fields `trend_direction` and `trend_pct` are excluded from the model feature matrix. Raw titles, URLs, domains, client names, IP addresses, and sensitive raw queries are not used.

## 3. Baseline

The baseline is a transparent hand-written rules score. On the recorded evaluation it achieved ROC AUC **0.627**, average precision **0.468**, and precision@50 **0.240**. This is the comparison point for judging whether the more complex models add useful prioritization signal.

## 4. Model / analysis

Three ML models were compared: logistic regression, decision tree, and random forest. The feature set includes search demand, content size/age, 90-day impressions/clicks/sessions, CTR, average position, engagement, scroll behavior, AI-traffic share, and non-label categorical descriptors such as competition level, content type, intent, age/freshness tier, word-count tier, impression tier, and position tier. The target is a binary indicator of observed decline, not a prediction of search-engine ranking or a causal outcome.

## 5. Evaluation

The primary split was a **client holdout** when the data contained enough distinct clients and both classes were represented in train and test; otherwise the pipeline falls back to a stratified row holdout. Model selection used precision@50 because the operational use case is a small prioritized review queue.

| Model | ROC AUC | Avg precision | Precision@50 | Recall | F1 |
|---|---:|---:|---:|---:|---:|
| Baseline rules | 0.627 | 0.468 | 0.240 | — | — |
| Logistic regression | 0.700 | 0.522 | 0.400 | 0.567 | 0.566 |
| Decision tree | 0.742 | 0.575 | 0.540 | 0.716 | 0.634 |
| **Random forest** | **0.750** | **0.618** | **0.740** | **0.744** | **0.640** |

The observed declining-label base rate is **54.2%**, so precision@50 is interpreted alongside AUC, average precision, and the baseline.

## 6. Interpretation

The largest feature importances were `days_with_impressions` (0.1578), `log_impressions_90d` (0.1282), `avg_position` (0.1090), `content_age_days` (0.0955), `char_count` (0.0426), and `word_count` (0.0397). These indicate which observed signals the random forest used most for discrimination in this dataset; they are not causal explanations.

The full scored queue contains 3,605 high-confidence, 11,395 medium-confidence, and 15,000 low-confidence items. Actions include 13,093 monitor, 8,178 refresh, 6,657 refresh-and-review-CTR, 1,990 refresh-and-review-engagement, and 82 expand-and-refresh recommendations.

## 7. Recommendation

Use the queue as a reviewer aid. Start with high-confidence items, inspect the associated reason codes and page context, and keep a human approval step before any content change. Monitor model performance against the baseline and retrain/re-evaluate when the underlying content or traffic distribution changes. Confidence is moderate for prioritization on this anonymized release and lower for unseen clients or causal claims.

## 8. Reproducibility

From a fresh clone:

```bash
pip install -r requirements.txt
python scripts/run_all.py
```

The pipeline runs feature preparation, baseline scoring, model training, evaluation/export, and PDF reporting. The repository records the main dependencies in `requirements.txt`; the training and client-shuffle logic use a fixed `RANDOM_STATE`.

## 9. Acknowledgments & data credit

Built on the **FlyRank ML Internship dataset**, with data/internship context credited to https://flyrank.ai.
